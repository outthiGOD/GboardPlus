import io.github.gboardplusru.LocalRules;
public final class TestLocalRules {
  public static void main(String[] args) {
    String input = "Здраствуйте , пожалуста ответьте! Привет привет!!!";
    String actual = LocalRules.apply(input, LocalRules.check(input));
    String expected = "Здравствуйте, пожалуйста ответьте! Привет!";
    if (!expected.equals(actual)) throw new AssertionError("Expected: " + expected + " actual: " + actual);
    if (LocalRules.exactTypo("Pixel") != null) throw new AssertionError("Must not flag unknown word");
    if (!"СДЕЛАТЬ".equals(LocalRules.exactTypo("ЗДЕЛАТЬ"))) throw new AssertionError("Case conversion");
    System.out.println("LocalRules OK: " + actual);
  }
}
