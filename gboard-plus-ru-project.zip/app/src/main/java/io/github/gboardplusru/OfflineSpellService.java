package io.github.gboardplusru;

import android.service.textservice.SpellCheckerService;
import android.view.textservice.SuggestionsInfo;
import android.view.textservice.TextInfo;

/** Minimal, fully offline Android SpellCheckerService. No network or keyboard access. */
public final class OfflineSpellService extends SpellCheckerService {
  @Override public Session createSession() { return new OfflineSession(); }

  private static final class OfflineSession extends Session {
    @Override public void onCreate() { }

    @Override public SuggestionsInfo onGetSuggestions(TextInfo textInfo, int suggestionsLimit) {
      String raw = textInfo == null ? "" : textInfo.getText();
      String suggestion = LocalRules.exactTypo(raw);
      if (suggestion != null && suggestionsLimit > 0) {
        return new SuggestionsInfo(
            SuggestionsInfo.RESULT_ATTR_LOOKS_LIKE_TYPO |
            SuggestionsInfo.RESULT_ATTR_HAS_RECOMMENDED_SUGGESTIONS,
            new String[] {suggestion}, textInfo.getCookie(), textInfo.getSequence());
      }
      // NOT marked as "in dictionary" because this is NOT a complete dictionary.
      return new SuggestionsInfo(0, new String[0],
          textInfo == null ? 0 : textInfo.getCookie(),
          textInfo == null ? 0 : textInfo.getSequence());
    }
  }
}
