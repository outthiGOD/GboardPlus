package io.github.gboardplusru;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/** Explicit text selection/editor UI; no accessibility service, clipboard scraping or key logging. */
public final class MainActivity extends Activity {
  private EditText editor;
  private TextView result;
  private Button applyButton;
  private Button sendBackButton;
  private List<LocalRules.Fix> pending = new ArrayList<>();
  private String checkedSnapshot = "";
  private String undoSnapshot = null;
  private boolean fromProcessText = false;
  private boolean readOnlySelection = false;

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    Intent incoming = getIntent();
    fromProcessText = Intent.ACTION_PROCESS_TEXT.equals(incoming.getAction());
    readOnlySelection = incoming.getBooleanExtra(Intent.EXTRA_PROCESS_TEXT_READONLY, false);

    ScrollView scroll = new ScrollView(this);
    LinearLayout body = new LinearLayout(this);
    body.setOrientation(LinearLayout.VERTICAL);
    int pad = (int)(14 * getResources().getDisplayMetrics().density);
    body.setPadding(pad, pad, pad, pad);
    scroll.addView(body);

    TextView title = new TextView(this);
    title.setText("Gboard Plus RU · v0.1");
    title.setTextSize(23);
    title.setTypeface(null, Typeface.BOLD);
    body.addView(title);

    TextView description = new TextView(this);
    description.setText("Gboard остаётся твоей клавиатурой.\n" +
        "Офлайн: только известные опечатки и простая пунктуация.\n" +
        "LanguageTool: только по кнопке; выбранный текст отправляется на сервер.\n" +
        "Не отправляй пароли, персональные данные и конфиденциальную переписку.");
    description.setTextSize(14);
    body.addView(description);

    TextView credit = new TextView(this);
    credit.setText("LanguageTool: https://languagetool.org");
    credit.setAutoLinkMask(android.text.util.Linkify.WEB_URLS);
    credit.setMovementMethod(android.text.method.LinkMovementMethod.getInstance());
    body.addView(credit);

    editor = new EditText(this);
    editor.setMinLines(6);
    editor.setGravity(android.view.Gravity.TOP);
    editor.setHint("Напиши текст или выбери его в другом приложении → Проверить текст");
    editor.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
        android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE |
        android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
    if (fromProcessText) {
      CharSequence selection = incoming.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);
      if (selection != null) editor.setText(selection.toString());
    }
    body.addView(editor);

    Button offline = button(body, "Проверить офлайн");
    offline.setOnClickListener(v -> {
      checkedSnapshot = editor.getText().toString();
      pending = LocalRules.check(checkedSnapshot);
      showFindings("Локальная проверка");
    });

    Button online = button(body, "Проверить LanguageTool (отправить текст в интернет)");
    online.setOnClickListener(v -> new AlertDialog.Builder(this)
      .setTitle("Разрешить отправку текста?")
      .setMessage("Текст из поля будет передан на api.languagetool.org для проверки. " +
          "Это разовое действие; фоновая отправка отключена.")
      .setNegativeButton("Отмена", null)
      .setPositiveButton("Отправить", (d, which) -> runLanguageTool())
      .show());

    applyButton = button(body, "Применить предложенные исправления");
    applyButton.setEnabled(false);
    applyButton.setOnClickListener(v -> {
      if (!checkedSnapshot.equals(editor.getText().toString())) {
        result.setText("Текст изменился после проверки. Выполни проверку ещё раз.");
        applyButton.setEnabled(false);
        return;
      }
      undoSnapshot = checkedSnapshot;
      String replacement = LocalRules.apply(checkedSnapshot, pending);
      editor.setText(replacement);
      checkedSnapshot = replacement;
      applyButton.setEnabled(false);
      result.setText("Исправления применены. Если результат неверный, нажми «Отменить».");
    });

    Button undo = button(body, "Отменить исправления");
    undo.setOnClickListener(v -> {
      if (undoSnapshot != null) {
        editor.setText(undoSnapshot);
        undoSnapshot = null;
        applyButton.setEnabled(false);
        result.setText("Предыдущий текст восстановлен.");
      }
    });

    sendBackButton = button(body, "Вернуть текст в исходное приложение");
    sendBackButton.setVisibility(fromProcessText && !readOnlySelection ? View.VISIBLE : View.GONE);
    sendBackButton.setOnClickListener(v -> {
      Intent data = new Intent();
      data.putExtra(Intent.EXTRA_PROCESS_TEXT, editor.getText().toString());
      setResult(RESULT_OK, data);
      finish();
    });

    Button settings = button(body, "Открыть настройки системной проверки");
    settings.setOnClickListener(v -> {
      try {
        startActivity(new Intent("android.settings.INPUT_METHOD_SETTINGS"));
      } catch (Exception e) {
        result.setText("Найди «Проверка правописания» через поиск в Настройках Android.");
      }
    });
    result = new TextView(this);
    result.setTextSize(15);
    result.setText("Включение нашей системной службы НЕ рекомендуется вместо Google до появления полноценного словаря. " +
        "Это экспериментальный офлайн-корректор небольшого набора ошибок.");
    result.setTextIsSelectable(true);
    body.addView(result);
    setContentView(scroll);
  }

  private Button button(LinearLayout parent, String name) {
    Button button = new Button(this);
    button.setText(name);
    parent.addView(button);
    return button;
  }

  private void showFindings(String label) {
    applyButton.setEnabled(!pending.isEmpty());
    if (pending.isEmpty()) {
      result.setText(label + ": найденных ошибок нет. Это НЕ означает, что текст гарантированно правильный.");
      return;
    }
    StringBuilder sb = new StringBuilder(label).append(": ").append(pending.size()).append(" замечаний\n\n");
    for (int i = 0; i < pending.size() && i < 50; i++) {
      LocalRules.Fix fix = pending.get(i);
      sb.append(i + 1).append(". ").append(fix).append('\n');
    }
    result.setText(sb.toString());
  }

  private void runLanguageTool() {
    final String snapshot = editor.getText().toString();
    if (snapshot.isEmpty()) { result.setText("Напиши или выдели текст для проверки."); return; }
    result.setText("Отправка текста в LanguageTool по твоему запросу…");
    new Thread(() -> {
      try {
        List<LocalRules.Fix> found = LanguageToolClient.manualCheck(snapshot);
        runOnUiThread(() -> {
          if (!snapshot.equals(editor.getText().toString())) {
            result.setText("Текст изменился во время проверки; результат отброшен.");
            return;
          }
          checkedSnapshot = snapshot;
          pending = found;
          showFindings("LanguageTool");
        });
      } catch (Exception e) {
        runOnUiThread(() -> result.setText("Проверка не выполнена: " + e.getMessage() +
            "\nПопробуй ещё раз позже или используй локальные правила."));
      }
    }, "manual-languagetool").start();
  }
}
