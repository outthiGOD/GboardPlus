package io.github.gboardplusru;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Only invoked when the user explicitly presses "Check LanguageTool". */
public final class LanguageToolClient {
  private LanguageToolClient() { }
  public static List<LocalRules.Fix> manualCheck(String text) throws Exception {
    if (text == null || text.isEmpty()) return Collections.emptyList();
    if (text.length() > 2500) throw new IllegalArgumentException("Не больше 2500 символов за один запрос");
    URL url = new URL("https://api.languagetool.org/v2/check");
    HttpURLConnection con = (HttpURLConnection) url.openConnection();
    try {
      con.setRequestMethod("POST");
      con.setConnectTimeout(7000);
      con.setReadTimeout(11000);
      con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
      con.setRequestProperty("User-Agent", "GboardPlusRU-Research/0.1 (manual proofreading; https://languagetool.org)");
      con.setDoOutput(true);
      byte[] body = ("text=" + URLEncoder.encode(text, "UTF-8") + "&language=ru-RU")
          .getBytes(StandardCharsets.UTF_8);
      try (OutputStream os = con.getOutputStream()) { os.write(body); }
      int code = con.getResponseCode();
      if (code != 200) throw new IllegalStateException("LanguageTool HTTP " + code);
      StringBuilder json = new StringBuilder();
      try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8))) {
        String line;
        while ((line = br.readLine()) != null) json.append(line);
      }
      JSONObject root = new JSONObject(json.toString());
      JSONArray matches = root.getJSONArray("matches");
      List<LocalRules.Fix> out = new ArrayList<>();
      for (int i = 0; i < matches.length() && i < 60; i++) {
        JSONObject m = matches.getJSONObject(i);
        int start = m.getInt("offset");
        int size = m.getInt("length");
        JSONArray replacements = m.optJSONArray("replacements");
        if (replacements == null || replacements.length() < 1) continue;
        String replacement = replacements.getJSONObject(0).optString("value", "");
        String message = m.optString("message", "орфография / грамматика");
        if (start >= 0 && size >= 0 && start + size <= text.length()) {
          out.add(new LocalRules.Fix(start, size, replacement, message));
        }
      }
      out.sort((a,b) -> Integer.compare(a.start, b.start));
      return out;
    } finally {
      con.disconnect();
    }
  }
}
