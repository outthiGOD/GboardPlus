package io.github.gboardplusru;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Conservative offline rules. This is NOT a full Russian spell-checking dictionary. */
public final class LocalRules {
  private LocalRules() { }

  private static final Map<String,String> TYPOS = new LinkedHashMap<>();
  static {
    TYPOS.put("здраствуйте", "здравствуйте");
    TYPOS.put("пожалуста", "пожалуйста");
    TYPOS.put("превет", "привет");
    TYPOS.put("извените", "извините");
    TYPOS.put("извеняюсь", "извиняюсь");
    TYPOS.put("сдесь", "здесь");
    TYPOS.put("ниразу", "ни разу");
    TYPOS.put("вообщем", "в общем");
    TYPOS.put("вобщем", "в общем");
    TYPOS.put("будте", "будьте");
    TYPOS.put("зделать", "сделать");
    TYPOS.put("зделал", "сделал");
    TYPOS.put("незнаю", "не знаю");
    TYPOS.put("щяс", "сейчас");
    TYPOS.put("впринципе", "в принципе");
    TYPOS.put("впоследствиии", "впоследствии");
    TYPOS.put("прийдется", "придётся");
  }

  public static String exactTypo(String word) {
    if (word == null) return null;
    String answer = TYPOS.get(word.toLowerCase(new Locale("ru")));
    if (answer == null) return null;
    return matchCase(word, answer);
  }

  private static String matchCase(String word, String answer) {
    if (word.equals(word.toUpperCase(new Locale("ru")))) {
      return answer.toUpperCase(new Locale("ru"));
    }
    if (!word.isEmpty() && Character.isUpperCase(word.charAt(0))) {
      return Character.toUpperCase(answer.charAt(0)) + answer.substring(1);
    }
    return answer;
  }

  public static final class Fix {
    public final int start;
    public final int length;
    public final String replacement;
    public final String reason;
    public Fix(int start, int length, String replacement, String reason) {
      this.start = start;
      this.length = length;
      this.replacement = replacement;
      this.reason = reason;
    }
    public String toString() {
      return (start + 1) + ": «" + replacement + "» — " + reason;
    }
  }

  public static List<Fix> check(String input) {
    List<Fix> out = new ArrayList<>();
    if (input == null || input.isEmpty()) return out;
    Matcher words = Pattern.compile("[\\p{L}]+", Pattern.UNICODE_CHARACTER_CLASS).matcher(input);
    while (words.find()) {
      String orig = words.group();
      String fixed = exactTypo(orig);
      if (fixed != null && !fixed.equals(orig)) {
        out.add(new Fix(words.start(), orig.length(), fixed, "опечатка"));
      }
    }
    Matcher spaces = Pattern.compile("[ \\t]+(?=[,.;:!?])").matcher(input);
    while (spaces.find()) {
      out.add(new Fix(spaces.start(), spaces.group().length(), "", "пробел перед знаком препинания"));
    }
    Matcher doubles = Pattern.compile("([\\p{L}]+)([ \\t]+)\\1(?=$|[^\\p{L}])",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE | Pattern.UNICODE_CHARACTER_CLASS).matcher(input);
    while (doubles.find()) {
      out.add(new Fix(doubles.start(2), doubles.group(2).length() + doubles.group(1).length(),
          "", "повтор слова"));
    }
    Matcher punctuation = Pattern.compile("([!?])\\1{2,}").matcher(input);
    while (punctuation.find()) {
      out.add(new Fix(punctuation.start(), punctuation.group().length(), punctuation.group(1), "повтор знака"));
    }
    Collections.sort(out, Comparator.comparingInt(a -> a.start));
    return out;
  }

  /** Returns unchanged text for overlapping edits; caller can preview or undo. */
  public static String apply(String original, List<Fix> fixes) {
    StringBuilder sb = new StringBuilder(original);
    int prior = original.length() + 1;
    for (int i = fixes.size() - 1; i >= 0; i--) {
      Fix f = fixes.get(i);
      if (f.start < 0 || f.length < 0 || f.start + f.length > original.length()) continue;
      if (f.start + f.length > prior) continue; // avoid overlapping patches
      sb.replace(f.start, f.start + f.length, f.replacement);
      prior = f.start;
    }
    return sb.toString();
  }
}
